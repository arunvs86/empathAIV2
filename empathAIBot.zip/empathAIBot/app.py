import os
from flask import Flask, request, jsonify
from flask_cors import CORS

from dotenv import load_dotenv
load_dotenv() 


# --- Import Langchain and related modules ---
from langchain.chains import create_history_aware_retriever, create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_chroma import Chroma
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_groq import ChatGroq
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader
from langchain_core.runnables.history import RunnableWithMessageHistory

# --- Flask App Initialization ---
app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "http://localhost:5173"}})  # Allow only your frontend

# --- Document Loading ---
# Instead of using Colab's file upload, we read the PDF from a local folder.
pdf_filename = os.path.join(os.getcwd(), "pdfs", "GriefBot.pdf")
loader = PyPDFLoader(pdf_filename)
documents = loader.load()

# Split document into chunks
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
splits = text_splitter.split_documents(documents)

print(f"Total Chunks: {len(splits)}")
print(f"First Chunk: {splits[0].page_content[:500]}")

# --- Vectorstore Setup ---
embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
vectorstore = Chroma.from_documents(documents=splits, embedding=embeddings)

# --- LLM and Chat Chain Setup ---
api_key = os.getenv("GROQ")
if api_key:
    llm = ChatGroq(groq_api_key=api_key, model_name="Gemma2-9b-It")
else:
    raise ValueError("GROQ API key not set.")

retriever = vectorstore.as_retriever(search_type="similarity", score_threshold=0.9, search_kwargs={"k": 3})

# Set up prompts for contextualizing the question
contextualize_q_system_prompt = (
    "Given a chat history and the latest user question, "
    "which might reference context in the chat history, "
    "formulate a standalone question that can be understood "
    "without the chat history. Do NOT answer the question, "
    "just reformulate it if needed and otherwise return it as is."
)

contextualize_q_prompt = ChatPromptTemplate.from_messages([
    ("system", contextualize_q_system_prompt),
    MessagesPlaceholder(variable_name="chat_history"),
    ("human", "{input}"),
])

history_aware_retriever = create_history_aware_retriever(llm, retriever, contextualize_q_prompt)

# Set up system prompt for Q&A
system_prompt = (

    "You are a compassionate therapist who offers grief support and mental health guidance."
    "Always be respectful, empathetic, and mindful of the user's emotions and beliefs."
    "Use a warm, human-like tone with natural, concise language. When engaging in casual conversation (e.g., greetings), respond in a friendly, natural manner." 
    "Avoid overly elaborate explanations unless specifically requested."
    "If it is about religious discussion, proceed and answer. But be very careful as it is sensitive."
    "Dont hurt the sentiments of anyone"
    "If a user's question is unclear or out of context, gently ask for clarification with a follow-up question." 
    "If the topic strays from available context, say, I am not sure about" 
    "Only use the relevant retrieved context to support your responses, and do not assume any additional details."
    "Maintain empathy and ensure your responses feel supportive and genuine."
    "Make sure to sound like a human"
    "\n\n{context}"
)

qa_prompt = ChatPromptTemplate.from_messages([
    ("system", system_prompt),
    MessagesPlaceholder(variable_name="chat_history"),
    ("human", "{input}"),
])

question_answer_chain = create_stuff_documents_chain(llm, qa_prompt)
rag_chain = create_retrieval_chain(history_aware_retriever, question_answer_chain)

# --- Session History Management ---
session_store = {}

def get_session_history(session: str) -> BaseChatMessageHistory:
    if session not in session_store:
        session_store[session] = ChatMessageHistory()
    return session_store[session]

def add_message_to_history(session: str, user_message: str, bot_response: str):
    session_store[session].add_user_message(user_message)
    session_store[session].add_ai_message(bot_response)

conversational_rag_chain = RunnableWithMessageHistory(
    rag_chain, get_session_history,
    input_messages_key="input",
    history_messages_key="chat_history",
    output_messages_key="answer"
)

def ask_bot(question, session_id="test_session"):
    session_history = get_session_history(session_id)
    retrieved_docs = retriever.get_relevant_documents(question)
    print(retrieved_docs)
    if not retrieved_docs:
        return "Couldn't find relevant information in the provided data."
    
    response = conversational_rag_chain.invoke(
        {"input": question, "chat_history": session_history.messages},
        config={"configurable": {"session_id": session_id}}
    )
    
    response_text = response["answer"]
    add_message_to_history(session_id, question, response_text)
    return response_text

# --- API Endpoints ---

@app.route("/")
def index():
    return "Chatbot API is running."

@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json()
    question = data.get("question")
    if not question:
        return jsonify({"error": "Question not provided"}), 400

    # Use provided session_id or generate a new one
    session_id = data.get("session_id") or str(uuid4())
    
    try:
        answer = ask_bot(question, session_id)
        return jsonify({"response": answer, "session_id": session_id})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    # Listen on all interfaces and use port 8080 for production environments.
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)), debug=True)

@app.route("/test-cors", methods=["GET"])
def test_cors():
    return jsonify({"message": "CORS is working!"})
